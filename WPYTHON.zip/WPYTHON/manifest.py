include("$(PORT_DIR)/boards/manifest.py")
freeze("modules")
