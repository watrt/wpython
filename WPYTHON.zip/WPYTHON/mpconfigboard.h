#define MICROPY_HW_BOARD_NAME "Wpython (spiram) 0.1"
#define MICROPY_HW_MCU_NAME "ESP32"
